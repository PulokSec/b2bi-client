export interface Business {
  id: string
  name: string
  formattedAddress?: string
  nationalPhoneNumber?: string
  internationalPhoneNumber?: string
  websiteUri?: string
  googleMapsUri?: string
  rating?: number
  userRatingCount?: number
  businessStatus?: string
  types?: string[]
  primaryType?: string
  contacts?: Contact[]
  emails?: string[]
  linkedIn?: string
  websiteInfo?: {
    hasSSL?: boolean
    websiteStatus?: string
    pageSpeed?: {
      performance?: number
      seo?: number
      accessibility?: number
    }
  }
  gptInsights?: string
}

export interface Contact {
  name: string
  position?: string
  email?: string
  phone?: string
}

export interface SearchQuery {
  id: string
  searchText: string
  createdAt: string
  results?: string[]
}
