"use server"

import type { Business, SearchQuery } from "@/lib/types"

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"

export async function searchBusinesses(searchText: string, count = 5) {
  try {
    const response = await fetch(`${API_URL}/google-place/search`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ searchText, count }),
    })

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error searching businesses:", error)
    throw error
  }
}

export async function getProcessingStatus() {
  // In a real app, this would fetch from an API endpoint
  // For demo purposes, we'll return mock data
  return {
    queries: [],
  }
}

export async function getSearchQueries(): Promise<SearchQuery[]> {
  // In a real app, this would fetch from an API endpoint
  // For demo purposes, we'll return mock data
  const response = await fetch(`${API_URL}/query`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
  return [
    {
      id: "1",
      searchText: "Plumber in Regina",
      createdAt: new Date().toISOString(),
    },
    {
      id: "2",
      searchText: "Plumber in Surrey",
      createdAt: new Date().toISOString(),
    },
    {
      id: "3",
      searchText: "Plumber in Vancouver",
      createdAt: new Date().toISOString(),
    },
  ]
}

export async function getBusinessesByQuery(query: string): Promise<Business[]> {
  // In a real app, this would fetch from an API endpoint
  // For demo purposes, we'll return mock data based on the query
  if (query === "Plumber in Regina") {
    return [
      {
        id: "1",
        name: "Quick Fix Plumbing",
        formattedAddress: "456 Queen St, Regina, SK S4T 1B2",
        nationalPhoneNumber: "(306) 555-2345",
        contacts: [
          { name: "Robert Johnson", position: "CEO" },
          { name: "John Smith", position: "Owner" },
        ],
      },
      {
        id: "2",
        name: "Regina Plumbing Solutions",
        formattedAddress: "123 Main St, Regina, SK S4P 3C5",
        nationalPhoneNumber: "(306) 555-5678",
        contacts: [
          { name: "Sarah Johnson", position: "Marketing Manager" },
          { name: "Mike Peterson", position: "Head Technician" },
        ],
      },
    ]
  } else if (query === "Plumber in Surrey") {
    return [
      {
        id: "3",
        name: "Surrey Plumbing Experts",
        formattedAddress: "789 King St, Surrey, BC V3T 2W1",
        nationalPhoneNumber: "(604) 555-7890",
        contacts: [{ name: "David Wilson", position: "Owner" }],
      },
    ]
  } else if (query === "Plumber in Vancouver") {
    return [
      {
        id: "4",
        name: "Vancouver Plumbing Co",
        formattedAddress: "567 Granville St, Vancouver, BC V6C 1Y6",
        nationalPhoneNumber: "(604) 555-1234",
        contacts: [
          { name: "Emily Chen", position: "Operations Manager" },
          { name: "James Wong", position: "Lead Plumber" },
        ],
      },
    ]
  }

  return []
}
