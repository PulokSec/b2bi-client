"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getBusinessesByQuery } from "@/lib/api"
import type { Business, SearchQuery } from "@/lib/types"

interface LeadsTableProps {
  queries: SearchQuery[]
}

export default function LeadsTable({ queries }: LeadsTableProps) {
  const [selectedQuery, setSelectedQuery] = useState<string | null>(queries.length > 0 ? queries[0].searchText : null)
  const [searchFilter, setSearchFilter] = useState("")
  const [businesses, setBusinesses] = useState<Business[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const fetchBusinesses = async () => {
      if (selectedQuery) {
        setLoading(true)
        try {
          const data = await getBusinessesByQuery(selectedQuery)
          setBusinesses(data)
        } catch (error) {
          console.error("Failed to fetch businesses:", error)
        } finally {
          setLoading(false)
        }
      }
    }

    fetchBusinesses()
  }, [selectedQuery])

  const filteredBusinesses = businesses.filter((business) => {
    const searchTerms = searchFilter.toLowerCase()
    return (
      business.name?.toLowerCase().includes(searchTerms) ||
      business.formattedAddress?.toLowerCase().includes(searchTerms) ||
      business.contacts?.some(
        (contact) =>
          contact.name?.toLowerCase().includes(searchTerms) || contact.position?.toLowerCase().includes(searchTerms),
      )
    )
  })

  return (
    <div className="w-full">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Left sidebar with queries */}
        <div className="w-full md:w-64 bg-gray-50 rounded-lg overflow-hidden">
          <div className="flex flex-col">
            {queries.map((query) => (
              <button
                key={query.id}
                className={`p-4 text-left hover:bg-blue-50 transition-colors ${
                  selectedQuery === query.searchText ? "bg-blue-100 border-l-4 border-blue-600" : ""
                }`}
                onClick={() => setSelectedQuery(query.searchText)}
              >
                {query.searchText}
              </button>
            ))}
          </div>
        </div>

        {/* Main content with leads table */}
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row gap-4 mb-4">
            <Input
              placeholder="Search"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="flex-1"
            />
            <Select defaultValue="all">
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="All Leads" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Leads</SelectItem>
                <SelectItem value="new">New Leads</SelectItem>
                <SelectItem value="contacted">Contacted</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b">
                    <th className="px-4 py-3 text-left text-blue-600">Company</th>
                    <th className="px-4 py-3 text-left text-blue-600">Address</th>
                    <th className="px-4 py-3 text-left text-blue-600">Contact</th>
                    <th className="px-4 py-3 text-left text-blue-600">Position</th>
                    <th className="px-4 py-3 text-left text-blue-600">Phone</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center">
                        Loading...
                      </td>
                    </tr>
                  ) : filteredBusinesses.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center">
                        No leads found
                      </td>
                    </tr>
                  ) : (
                    filteredBusinesses.map((business) => (
                      <tr key={business.id} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-4">{business.name}</td>
                        <td className="px-4 py-4">{business.formattedAddress}</td>
                        <td className="px-4 py-4">
                          {business.contacts?.map((contact, index) => (
                            <div key={index} className="mb-2">
                              {contact.name}
                            </div>
                          ))}
                        </td>
                        <td className="px-4 py-4">
                          {business.contacts?.map((contact, index) => (
                            <div key={index} className="mb-2">
                              {contact.position}
                            </div>
                          ))}
                        </td>
                        <td className="px-4 py-4">{business.nationalPhoneNumber}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
