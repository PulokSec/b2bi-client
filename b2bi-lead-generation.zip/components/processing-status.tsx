"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getProcessingStatus } from "@/lib/api"

export default function ProcessingStatus() {
  const [processingQueries, setProcessingQueries] = useState<string[]>([])

  useEffect(() => {
    const fetchStatus = async () => {
      const status = await getProcessingStatus()
      setProcessingQueries(status.queries || [])
    }

    fetchStatus()

    // Poll for updates every 5 seconds
    const interval = setInterval(fetchStatus, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl text-blue-600">Currently Processing</CardTitle>
      </CardHeader>
      <CardContent>
        {processingQueries.length > 0 ? (
          <ul className="space-y-2">
            {processingQueries.map((query, index) => (
              <li key={index} className="italic">
                {query}
              </li>
            ))}
          </ul>
        ) : (
          <p className="italic text-gray-500">No keywords currently being processed.</p>
        )}
      </CardContent>
    </Card>
  )
}
