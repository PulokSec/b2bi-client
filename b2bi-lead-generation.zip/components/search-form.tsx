"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { searchBusinesses } from "@/lib/api"

export default function SearchForm() {
  const [searchText, setSearchText] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!searchText.trim()) {
      toast({
        title: "Search field is empty",
        description: "Please enter a keyword to search for businesses",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      toast({
        title: "Processing search",
        description: `Searching for "${searchText}"...`,
      })

      // Start the search process
      await searchBusinesses(searchText)

      // Redirect to the my-leads page
      router.push("/my-leads")
    } catch (error) {
      toast({
        title: "Search failed",
        description: "An error occurred while processing your search",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-4">
      <Input
        type="text"
        placeholder="e.g., Plumber in Regina"
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
        className="flex-1"
      />
      <Button type="submit" disabled={isLoading} className="bg-blue-600 hover:bg-blue-700 text-white">
        Get me fresh leads
      </Button>
    </form>
  )
}
